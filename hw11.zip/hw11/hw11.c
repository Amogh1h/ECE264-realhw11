#include "hw11.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Global variables definition
char titles[MAX_TITLES][MAX_TITLE_LENGTH];
int title_count = 0;

char* read_xml_file(const char* filename) {
    
}

// Recursive function to find and store book titles
void find_titles_recursive(const char *xml) {
    
}

// Sort titles alphabetically
void sort_titles_alphabetically() {

}

// Print all stored titles
void print_titles() {

}